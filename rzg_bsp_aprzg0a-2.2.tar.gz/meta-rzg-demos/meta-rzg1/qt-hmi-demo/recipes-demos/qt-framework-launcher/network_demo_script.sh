#!/bin/bash

/usr/share/qt5/examples/network/fortuneserver/fortuneserver &
/usr/share/qt5/examples/network/fortuneclient/fortuneclient &
