#include <iostream>

int main(void)
{
	std::cout << "hello world" << std::endl;

	return 0;
}
