#!/bin/sh

GTK_MODULES=libgtkstylus.so

export GTK_MODULES
