/*
 * Renesas Proprietary Information.
 * The information contained herein is confidential property of
 * Renesas Electronics Corporation
 *
 * Copyright (C) Renesas Electronics Corporation 2013 All rights reserved.
 */
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include "mmngr_user_public.h"

void one_test(unsigned long flag)
{
	int		ret;
	MMNGR_ID	id;
	MMNGR_ID	ids;
	int		i;
	unsigned char	*p;
	unsigned long	phy_addr;
	unsigned long	hard_addr;
	unsigned long	user_virt_addr;
	unsigned long	user_virt_addr_s;
	unsigned long	size = 256 * 1024;

	printf("one START-------------\n");

	ret = mmngr_alloc_in_user(&id, size, &phy_addr, &hard_addr,
				&user_virt_addr, flag);
	if (ret)
		goto exit;

	printf("phy_addr %x, hard_addr %x, user_virt_addr %x\n",
		phy_addr, hard_addr, user_virt_addr);

	if (flag == MMNGR_VA_SUPPORT) {
		p = (unsigned char *)user_virt_addr;
		for (i = 0; i < size; i++)
			p[i] = 0xCC;
		for (i = 0; i < size; i++) {
			if (p[i] != 0xCC)
				goto exit;
		}
	}

	ret = mmngr_free_in_user(id);
	if (ret)
		goto exit;

	if (flag == MMNGR_PA_SUPPORT) {
		ret = mmngr_alloc_in_user(&id, size, &phy_addr,
					&hard_addr, &user_virt_addr, flag);
		if (ret)
			goto exit;

		ret = mmngr_debug_map_va(&ids, size, hard_addr,
					&user_virt_addr_s);
		if (ret)
			goto exit;

		printf("phy(%x), hard(%x), virt(%x), share(%x)\n",
			phy_addr, hard_addr, user_virt_addr, user_virt_addr_s);

		p = (unsigned char *)user_virt_addr_s;

		for (i = 0; i < size; i++)
			p[i] = 0xCC;

		for (i = 0; i < size; i++)
			if (p[i] != 0xCC)
				goto exit;

		ret = mmngr_debug_unmap_va(ids);
		if (ret)
			goto exit;

		ret = mmngr_free_in_user(id);
		if (ret)
			goto exit;
	}

	if (flag == MMNGR_PA_SUPPORT_MV) {
		ret = mmngr_alloc_in_user(&id, size, &phy_addr,
					&hard_addr, &user_virt_addr, flag);
		if (ret)
			goto exit;

		ret = mmngr_debug_map_va(&ids, size, hard_addr,
					&user_virt_addr_s);
		if (ret)
			goto exit;

		printf("phy(%x), hard(%x), virt(%x), share(%x)\n",
			phy_addr, hard_addr, user_virt_addr, user_virt_addr_s);

		p = (unsigned char *)user_virt_addr_s;

		for (i = 0; i < size; i++)
			p[i] = 0xCC;

		for (i = 0; i < size; i++)
			if (p[i] != 0xCC)
				goto exit;

		ret = mmngr_debug_unmap_va(ids);
		if (ret)
			goto exit;

		ret = mmngr_free_in_user(id);
		if (ret)
			goto exit;
	}

	printf("virt(%08x) to phys(%llx)\n",
		0x38000000, mmngr_ipmmu_virt_to_phys(0x38000000));
	printf("phys(%08x) to virt(%08x)\n",
		0x78000000, mmngr_ipmmu_phys_to_virt(0x78000000));
	printf("phys(%llx) to virt(%08x)\n",
		0x138000000, mmngr_ipmmu_phys_to_virt(0x138000000));

	printf("test OK\n");
	printf("one END-------------\n");
	return;

exit:
	printf("test NG\n");
	printf("one END-------------\n");
	return;
}

void test(unsigned long flag)
{
	one_test(flag);
	printf("\n");
	sleep(1);
}

int main(int argc, char *argv[])
{
	test(MMNGR_VA_SUPPORT);
	test(MMNGR_PA_SUPPORT);
	test(MMNGR_PA_SUPPORT_MV);

	return 0;
exit:
	return -1;
}

