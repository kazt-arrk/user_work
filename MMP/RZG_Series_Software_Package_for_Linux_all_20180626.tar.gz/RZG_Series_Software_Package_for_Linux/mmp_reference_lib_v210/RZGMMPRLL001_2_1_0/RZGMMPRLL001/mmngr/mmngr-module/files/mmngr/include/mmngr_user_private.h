/*
 * Renesas Proprietary Information.
 * The information contained herein is confidential property of
 * Renesas Electronics Corporation
 *
 * Copyright (C) Renesas Electronics Corporation 2013 All rights reserved.
 */
#ifndef __MMNGR_USER_PRIVATE_H__
#define __MMNGR_USER_PRIVATE_H__

#define DEVFILE "/dev/rgnmm"

struct MM_PARAM {
	unsigned long	size;
	unsigned long long	phy_addr;
	unsigned long	hard_addr;
	unsigned long	user_virt_addr;
	unsigned long	kernel_virt_addr;
	unsigned long	flag;
};

#define MM_IOC_MAGIC 'm'
#define MM_IOC_ALLOC	_IOWR(MM_IOC_MAGIC, 0, struct MM_PARAM)
#define MM_IOC_FREE	_IOWR(MM_IOC_MAGIC, 1, struct MM_PARAM)
#define MM_IOC_SET	_IOWR(MM_IOC_MAGIC, 2, struct MM_PARAM)
#define MM_IOC_GET	_IOWR(MM_IOC_MAGIC, 3, struct MM_PARAM)
#define MM_IOC_ALLOC_CO	_IOWR(MM_IOC_MAGIC, 4, struct MM_PARAM)
#define MM_IOC_FREE_CO	_IOWR(MM_IOC_MAGIC, 5, struct MM_PARAM)
#define MM_IOC_SHARE	_IOWR(MM_IOC_MAGIC, 6, struct MM_PARAM)

static int mm_alloc_kh_in_user(MMNGR_ID *pid, unsigned long size,
				unsigned long *pphy_addr,
				unsigned long *phard_addr,
				unsigned long *puser_virt_addr,
				unsigned long flag);
static int mm_free_kh_in_user(MMNGR_ID id);
static int mm_alloc_co_in_user(MMNGR_ID *pid, unsigned long size,
				unsigned long *pphy_addr,
				unsigned long *phard_addr,
				unsigned long *puser_virt_addr,
				unsigned long flag);
static int mm_free_co_in_user(MMNGR_ID id);
static unsigned long long mmngr_ipmmu_phys_to_s3(unsigned long long paddr);

enum {
	IPMMUSY0_DOMAIN = 0,
	IPMMUSY1_DOMAIN,
	IPMMUDS_DOMAIN,
	IPMMUMP_DOMAIN,
	IPMMUMX_DOMAIN,
	IPMMURT_DOMAIN,
	IPMMUGP_DOMAIN,
	IPMMU_DOMAIN_MAX
};

#ifdef MMNGR_KOELSCH
#define IPMMU_ADDR_SECTION_0	0x0100000000ULL
#define IPMMU_ADDR_SECTION_1	0x0200000000ULL
#define IPMMU_ADDR_SECTION_2	0x0ULL
#define IPMMU_ADDR_SECTION_3	0x0ULL
#define IPMMU_PGDVAL_SECTION_0	IPMMU_PGDVAL(IPMMU_ADDR_SECTION_0)
#define IPMMU_PGDVAL_SECTION_1	IPMMU_PGDVAL(IPMMU_ADDR_SECTION_1)
#define IPMMU_PGDVAL_SECTION_2	0x0ULL
#define IPMMU_PGDVAL_SECTION_3	0x0ULL
#else
#define IPMMU_ADDR_SECTION_0	0x0100000000ULL
#define IPMMU_ADDR_SECTION_1	0x0140000000ULL
#define IPMMU_ADDR_SECTION_2	0x0180000000ULL
#define IPMMU_ADDR_SECTION_3	0x01c0000000ULL
#define IPMMU_PGDVAL_SECTION_0	IPMMU_PGDVAL(IPMMU_ADDR_SECTION_0)
#define IPMMU_PGDVAL_SECTION_1	IPMMU_PGDVAL(IPMMU_ADDR_SECTION_1)
#define IPMMU_PGDVAL_SECTION_2	IPMMU_PGDVAL(IPMMU_ADDR_SECTION_2)
#define IPMMU_PGDVAL_SECTION_3	IPMMU_PGDVAL(IPMMU_ADDR_SECTION_3)
#endif

#define IPMMU_KERNEL_PHY_ADDR		0x0040000000ULL
#define IPMMU_KERNEL_PHY_MIRROR_ADDR	0x0100000000ULL
#define IPMMU_KERNEL_LEGACY_MEM_SIZE	0x0040000000ULL

#define SZ_1G				0x40000000

static unsigned long long r8a779x_ipmmu_trans_table[IPMMU_DOMAIN_MAX][4] = {
/* IPMMUSY0 */
{IPMMU_ADDR_SECTION_0, IPMMU_ADDR_SECTION_1,
IPMMU_ADDR_SECTION_2, IPMMU_ADDR_SECTION_3},
/* IPMMUSY1 */
{IPMMU_ADDR_SECTION_0, IPMMU_ADDR_SECTION_1,
IPMMU_ADDR_SECTION_2, IPMMU_ADDR_SECTION_3},
/* IPMMUDS */
{IPMMU_ADDR_SECTION_0, IPMMU_ADDR_SECTION_1,
IPMMU_ADDR_SECTION_2, IPMMU_ADDR_SECTION_3},
/* IPMMUMP */
{IPMMU_ADDR_SECTION_0, IPMMU_ADDR_SECTION_1,
IPMMU_ADDR_SECTION_2, IPMMU_ADDR_SECTION_3},
/* IPMMUMX */
{IPMMU_ADDR_SECTION_0, IPMMU_ADDR_SECTION_1,
IPMMU_ADDR_SECTION_2, IPMMU_ADDR_SECTION_3},
/* IPMMURT */
{IPMMU_ADDR_SECTION_0, IPMMU_ADDR_SECTION_1,
IPMMU_ADDR_SECTION_2, IPMMU_ADDR_SECTION_3},
/* IPMMUGP */
{IPMMU_ADDR_SECTION_0, IPMMU_ADDR_SECTION_1,
IPMMU_ADDR_SECTION_2, IPMMU_ADDR_SECTION_3},
};

/*#define MMNGR_IPMMU_ENABLE*/

#endif	/* __MMNGR_USER_PRIVATE_H__ */
