#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>

#include "fdpm_api.h"
#include "mmngr_user_public.h"

#define NUM_FRAME 6
#define NUM_PLANE 3
#define NUM_RPF   3

sem_t start_sem;

void ufunc_open(void);
void callback1_start(T_FDP_CB1 *disp_cb1);
void callback2_start(T_FDP_CB2 *disp_cb2);
void ufunc_close(void);

int main(int argc, char *argv[])
{
  int vbest_file_descriptor;
  T_FDP_OPEN para_test_open;
  T_FDP_REFPREBUF *test_refprebuf;
  T_FDP_IMGSIZE para_test_insize;
  T_FDP_START *para_test_start;
  unsigned long para_test_vcnt;
  T_FDP_FPROC *para_test_fproc;
  T_FDP_SEQ *para_test_seq;
  T_FDP_PIC *para_test_in_pic;
  T_FDP_PICPAR *para_test_pic_par;
  T_FDP_REFBUF *para_test_refbuf;
  T_FDP_IMGBUF str_refimgbuf[3];
  T_FDP_IMGBUF str_outimgbuf;

  MMNGR_ID mmngr_fd;
  unsigned long mmngr_phys, mmngr_hw, mmngr_cpu;

  int ercd;
  int rt_code;
  int x,y;
  int in_fsize;
  int input_hsize, input_vsize;
  int out_maxsize;
  int mmngr_size, input_area_size;
  unsigned long *pRef[NUM_FRAME][NUM_PLANE], *pOut[NUM_FRAME][NUM_PLANE];
  unsigned long *pRefCpu[NUM_FRAME][NUM_PLANE], *pOutCpu[NUM_FRAME][NUM_PLANE];
  unsigned char *dump_pt;
  int curr_frame;
  int callback1_arg;
  int callback2_arg;
  int i;
  FILE *fpo;
  char out_file_name[50];


  input_hsize = 80;
  input_vsize = 40;

  in_fsize = input_hsize * input_vsize;
  out_maxsize = input_hsize * input_vsize * 2;

  mmngr_size = in_fsize * NUM_PLANE * NUM_FRAME + out_maxsize * NUM_PLANE * NUM_FRAME;

  /* allocate memory for input/output image buffer */
  ercd = mmngr_alloc_in_user (&mmngr_fd, mmngr_size, &mmngr_phys, &mmngr_hw, &mmngr_cpu, MMNGR_VA_SUPPORT);
  if (ercd != 0) {
    printf("MMNGR alloc ERROR: code = %d\n", ercd);
    return 0;
  }

  for(y=0; y<NUM_FRAME; y++) {
    for(x=0; x<3; x++) {
      pRef   [y][x] = (unsigned long *)(mmngr_hw  + (3*y + x)* in_fsize);
      pRefCpu[y][x] = (unsigned long *)(mmngr_cpu + (3*y + x)* in_fsize);
    }
  }

  input_area_size = in_fsize * NUM_PLANE * NUM_FRAME;

  for(y=0; y<NUM_FRAME; y++) {
    for(x=0; x<3; x++) {
      pOut   [y][x] = (unsigned long *)(mmngr_hw  + input_area_size + (3*y + x)* out_maxsize);
      pOutCpu[y][x] = (unsigned long *)(mmngr_cpu + input_area_size + (3*y + x)* out_maxsize);
    }
  }


  /* Generate input image                           */
  /* Fill even line white and odd line black        */
  /* format:FDP_YUV420 (NV12)(no use pRefCpu[*][2]) */
  for(y=0; y<NUM_FRAME; y++) {
    for(x=0;x<in_fsize;x++) {
      *((unsigned char *)pRefCpu[y][0] + x) = (y % 2)? 0: 255;
      *((unsigned char *)pRefCpu[y][1] + x) = 0x80;
      *((unsigned char *)pRefCpu[y][2] + x) = 0x80;
    }
  }

  /* initialize output buffer */
  for(y=0; y<NUM_FRAME; y++) {
    for(x=0;x<out_maxsize;x++) {
      *((unsigned char *)pOutCpu[y][0] + x) = 0x55;
      *((unsigned char *)pOutCpu[y][1] + x) = 0xAA;
      *((unsigned char *)pOutCpu[y][2] + x) = 0xAA;
    }
  }

  sem_init(&start_sem, 0, 0);

  memset(&para_test_open,0x0, sizeof(T_FDP_OPEN));

  /* make open parameter */
  para_test_open.ref_mode = 0;
  para_test_open.refbuf_mode = 0;
  para_test_open.refbuf = NULL;
  para_test_open.ocmode = FDP_OCMODE_OCCUPY;
  para_test_open.vmode = FDP_VMODE_VBEST;
  para_test_open.insize = &para_test_insize;
  para_test_open.clkmode = FDP_CLKMODE_1;
  para_test_open.vcnt = 166;
  para_test_insize.width = input_hsize;
  para_test_insize.height = input_vsize;

  /* FDPM open */
  rt_code = drv_FDPM_Open (
			   NULL, // callback2
			   NULL, // callback3
			   NULL, // callback4
			   &para_test_open, // open parameter
			   ufunc_open, //user function
			   NULL,// callback2 arg
			   NULL,// callback3 arg
			   NULL,// callback4 arg
			   (int *)&vbest_file_descriptor
			   );
  if (rt_code != 0) {
    printf("Error at drv_FDPM_Open:%d %d\n",rt_code, vbest_file_descriptor);
    goto exit;
  }


  /* make start parameter */
  if ( (para_test_start = (T_FDP_START *)malloc(sizeof(T_FDP_START))) == NULL) {
    printf("Fail malloc (para_test_start)\n");
    goto exit;
  }
  memset(para_test_start, 0x0, sizeof(T_FDP_START));

  if ( (para_test_fproc = (T_FDP_FPROC *)malloc(sizeof(T_FDP_FPROC))) == NULL) {
    printf("Fail malloc (para_test_fproc)\n");
    goto exit;
  }
  memset(para_test_fproc, 0x0, sizeof(T_FDP_FPROC));

  if ( (para_test_seq = (T_FDP_SEQ *)malloc(sizeof(T_FDP_SEQ))) == NULL) {
    printf("Fail malloc (para_test_seq)\n");
    goto exit;
  }
  memset(para_test_seq, 0x0, sizeof(T_FDP_SEQ));

  if ( (para_test_in_pic = (T_FDP_PIC *)malloc(sizeof(T_FDP_PIC))) == NULL) {
    printf("Fail malloc (para_test_in_pic)\n");
    goto exit;
  }
  memset(para_test_in_pic, 0x0, sizeof(T_FDP_PIC));

  if ( (para_test_pic_par = (T_FDP_PICPAR *)malloc(sizeof(T_FDP_PICPAR))) == NULL) {
    printf("Fail malloc (para_test_pic_par)\n");
    goto exit;
  }
  memset(para_test_pic_par, 0x0, sizeof(T_FDP_PICPAR));

  if ( (para_test_refbuf = (T_FDP_REFBUF *)malloc(sizeof(T_FDP_REFBUF))) == NULL) {
    printf("Fail malloc (poara_test_refbuf)\n");
    goto exit;
  }
  memset(para_test_refbuf, 0x0, sizeof(T_FDP_REFBUF));

  para_test_start->vcnt = &para_test_vcnt;
  para_test_start->fdpgo = FDP_GO;
  para_test_start->fproc_par = para_test_fproc;
  para_test_vcnt = 166;
  para_test_fproc->seq_par = para_test_seq;
  para_test_fproc->in_pic = para_test_in_pic;
  para_test_fproc->last_start = 0;
  para_test_fproc->cf = 0;
  para_test_fproc->f_decodeseq = 0;
  para_test_fproc->ref_buf = para_test_refbuf;
  para_test_fproc->out_buf = &str_outimgbuf;
  para_test_fproc->out_format = FDP_YUV420;
  para_test_seq->seq_mode = FDP_SEQ_INTER;
  para_test_seq->telecine_mode = FDP_TC_OFF;
  para_test_seq->in_width = input_hsize;
  para_test_seq->in_height = input_vsize;
  para_test_seq->ratio = NULL;
  para_test_in_pic->pic_par = para_test_pic_par;
  para_test_pic_par->width = input_hsize;
  para_test_pic_par->height = input_vsize;
  para_test_pic_par->chroma_format = FDP_YUV420;
  para_test_pic_par->progressive_sequence = 0;
  para_test_pic_par->progressive_frame = 0;
  para_test_pic_par->picture_structure = 0;
  para_test_pic_par->repeat_first_field = 0;
  para_test_pic_par->top_field_first = 0;
  para_test_refbuf->buf_refwr = NULL;
  para_test_refbuf->buf_refrd0 = &str_refimgbuf[0];
  para_test_refbuf->buf_refrd1 = &str_refimgbuf[1];
  para_test_refbuf->buf_refrd2 = &str_refimgbuf[2];
  para_test_refbuf->buf_iirwr = NULL;
  para_test_refbuf->buf_iirrd = NULL;

  str_refimgbuf[0].stride = input_hsize;
  str_refimgbuf[0].stride_c = input_hsize;
  str_refimgbuf[1].stride = input_hsize;
  str_refimgbuf[1].stride_c = input_hsize;
  str_refimgbuf[2].stride = input_hsize;
  str_refimgbuf[2].stride_c = input_hsize;
  
  str_outimgbuf.stride = input_hsize;
  str_outimgbuf.stride_c = input_hsize;

  /* frame loop */
  for (curr_frame = 0; curr_frame<NUM_FRAME; curr_frame++) {
    
    /* setting input/output buffer address */
    str_refimgbuf[0].addr    = pRef[(curr_frame+1) % NUM_FRAME][0];
    str_refimgbuf[0].addr_c0 = pRef[(curr_frame+1) % NUM_FRAME][1];
    str_refimgbuf[0].addr_c1 = pRef[(curr_frame+1) % NUM_FRAME][2];
    str_refimgbuf[1].addr    = pRef[(curr_frame  ) % NUM_FRAME][0];
    str_refimgbuf[1].addr_c0 = pRef[(curr_frame  ) % NUM_FRAME][1];
    str_refimgbuf[1].addr_c1 = pRef[(curr_frame  ) % NUM_FRAME][2];
    str_refimgbuf[2].addr    = pRef[(curr_frame+NUM_FRAME-1) % NUM_FRAME][0];
    str_refimgbuf[2].addr_c0 = pRef[(curr_frame+NUM_FRAME-1) % NUM_FRAME][1];
    str_refimgbuf[2].addr_c1 = pRef[(curr_frame+NUM_FRAME-1) % NUM_FRAME][2];
    if(para_test_start->fproc_par->out_buf != NULL) {
      str_outimgbuf.addr     = pOut[curr_frame % NUM_FRAME][0];
      str_outimgbuf.addr_c0  = pOut[curr_frame % NUM_FRAME][1];
      str_outimgbuf.addr_c1  = pOut[curr_frame % NUM_FRAME][2];
    }

    /* set NULL to seq_par for same sequence */
    if(curr_frame != 0) {
      para_test_fproc->seq_par = NULL;
    }
    /* for last frame, set last_start to 1 */
    if(curr_frame == NUM_FRAME - 1) {
      para_test_fproc->last_start = 1;
    }

    callback1_arg = curr_frame;
    callback2_arg = curr_frame + 10;
    
    /* execute IP convertion process */
    rt_code = drv_FDPM_Start(
			     callback1_start,
			     callback2_start,
			     para_test_start,
			     &callback1_arg, // callback1 arg
			     &callback2_arg, // callback2 arg
			     (int *)&vbest_file_descriptor
			     );

    /* wait callback2 */
    sem_wait(&start_sem);

    /* dump output data */
    sprintf(out_file_name,"out_data_%03d.yuv",curr_frame);
    if((fpo = fopen(out_file_name,"w")) == NULL) {
      printf("Can not open file:%s\n",out_file_name);
    } else {
      for(i=0;i<input_vsize*2;i++){
	dump_pt = (unsigned char *)pOutCpu[curr_frame][0] + i*input_hsize;
	fwrite(dump_pt, sizeof(char),input_hsize,fpo);
      }
      for(i=0;i<input_vsize;i++){
	dump_pt = (unsigned char *)pOutCpu[curr_frame][1] + i*input_hsize;
	fwrite(dump_pt, sizeof(char),input_hsize,fpo);
      }
      fclose(fpo);
    }

    /* current field change */
    para_test_fproc->cf = (para_test_fproc->cf)? 0: 1;

  }
  /* end of frame */

  /* FDPM close */
  rt_code = drv_FDPM_Close(
			   ufunc_close,
			   (int *)&vbest_file_descriptor,
			   0
			   );

 exit:
  if(para_test_refbuf != NULL) {
    free(para_test_refbuf);
  }
  if(para_test_pic_par != NULL) {
    free(para_test_pic_par);
  }
  if(para_test_in_pic != NULL) {
    free(para_test_in_pic);
  }
  if(para_test_seq != NULL) {
    free(para_test_seq);
  }
  if(para_test_fproc != NULL) {
    free(para_test_fproc);
  }
  if(para_test_start != NULL) {
    free(para_test_start);
  }

  /* free memory */
  ercd = mmngr_free_in_user(mmngr_fd);
  if (ercd != 0) {
    printf("MMNGR free ERROR: code = %d\n",ercd);
    return 0;
  }

  sem_destroy(&start_sem);

  return 0;
}

void ufunc_open (void)
{
  printf("[open]user function execute.\n");
}

void callback1_start(T_FDP_CB1 *disp_cb1)
{
  int *tmp, *tmp2;
  int default_null = 0xAA;

  tmp = disp_cb1->userdata1;
  if(tmp != NULL) {
    tmp2 = (int *)*tmp;
  } else {
    tmp2 = (int *)default_null;
  }
  printf("callback1_start:%d\n",(unsigned int)tmp2);
}

void callback2_start(T_FDP_CB2 *disp_cb2)
{
  int *tmp, *tmp2;
  int default_null = 0xAA;
  tmp = disp_cb2->userdata2;
  
  if(tmp != NULL) {
    tmp2 = (int *)*tmp;
  } else{
    tmp2 = (int *)default_null;
  }
  printf("callback2_start:%d %x\n",disp_cb2->ercd,(int)tmp2);

  sem_post(&start_sem);
}

void ufunc_close(void)
{
  printf("[close]user function execute.\n");
}
