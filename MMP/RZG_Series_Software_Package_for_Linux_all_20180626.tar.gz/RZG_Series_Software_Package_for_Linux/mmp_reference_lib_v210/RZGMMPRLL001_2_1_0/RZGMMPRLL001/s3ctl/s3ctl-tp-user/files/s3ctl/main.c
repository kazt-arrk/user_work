/*
 * Renesas Proprietary Information.
 * The information contained herein is confidential property of
 * Renesas Electronics Corporation
 *
 * Copyright (C) Renesas Electronics Corporation 2013 All rights reserved.
 */
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include "s3ctl_user_public.h"

void one_test(void)
{
	S3CTL_ID	id;
	int		ret;
	struct S3_PARAM	p;
	struct S3_PARAM	gp;

	printf("one pass START-----------\n");

	ret = s3ctl_open(&id);
	if (ret)
		goto exit;

	p.phy_addr = 0x50000;
	p.stride = S3_STRIDE_1K;
	p.area = S3_AREA_256K;
	ret = s3ctl_set_param(id, &p);
	if (ret)
		goto exit;

	ret = s3ctl_get_param(id, &gp);
	printf("addr %x, stride %ld, area %ld\n",
		(unsigned int)gp.phy_addr, gp.stride, gp.area);	
	if (ret)
		goto exit;

	ret = s3ctl_lock(id);
	if (ret)
		goto exit;

	ret = s3ctl_unlock(id);
	if (ret)
		goto exit;

	ret = s3ctl_clear_param(id);
	if (ret)
		goto exit;

	p.phy_addr = 0x58000;
	p.stride = S3_STRIDE_2K;
	p.area = S3_AREA_128K;
	ret = s3ctl_set_param(id, &p);
	if (ret)
		goto exit;

	ret = s3ctl_get_param(id, &gp);
	printf("addr %x, stride %ld, area %ld\n",
		(unsigned int)gp.phy_addr, gp.stride, gp.area);	
	if (ret)
		goto exit;

	ret = s3ctl_lock(id);
	if (ret)
		goto exit;

	ret = s3ctl_unlock(id);
	if (ret)
		goto exit;

	ret = s3ctl_clear_param(id);
	if (ret)
		goto exit;

	ret = s3ctl_close(id);
	if (ret)
		goto exit;

	printf("test OK\n");
	printf("one pass END-------------\n");
	return;
exit:
	printf("test NG\n");
	printf("one pass END-------------\n");
	return;
}

void test(void)
{
	int	ret;

	printf("\n");

	one_test();
	printf("\n");
	sleep(1);

	return;
}

int main(int argc,char *argv[])
{
	test();

	return 0;
}

