/*************************************************************************/ /*
 VSPM

 Copyright (C) 2013-2014 Renesas Electronics Corporation

 License        Dual MIT/GPLv2

 The contents of this file are subject to the MIT license as set out below.

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 Alternatively, the contents of this file may be used under the terms of
 the GNU General Public License Version 2 ("GPL") in which case the provisions
 of GPL are applicable instead of those above.

 If you wish to allow use of your version of this file only under the terms of
 GPL, and not to allow others to use your version of this file under the terms
 of the MIT license, indicate your decision by deleting the provisions above
 and replace them with the notice and other provisions required by GPL as set
 out in the file called "GPL-COPYING" included in this distribution. If you do
 not delete the provisions above, a recipient may use your version of this file
 under the terms of either the MIT license or GPL.

 This License is also included in this distribution in the file called
 "MIT-COPYING".

 EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


 GPLv2:
 If you wish to use this file under the terms of GPL, following terms are
 effective.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; version 2 of the License.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/ /*************************************************************************/

#include <asm/uaccess.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/platform_device.h>
#include <linux/slab.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/dma-mapping.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/pm_runtime.h>
#include <linux/clk.h>

#include "frame.h"
#include "vspm_public.h"
#include "vspm_private.h"
#include "vspm_main.h"
#include "vspm_log.h"

/*
 * vspm_thread - VSPM thread main routine
 * @num:
 *
 */
static int vspm_thread(void *num)
{
	DPRINT("called\n");

	vspm_task();

	DPRINT("done\n");
	return 0;
}

/*
 * vspm_init - Initialize the VSPM thread
 * @priv: VSPM driver private data
 *
 */
int vspm_init(struct vspm_privdata *priv)
{
	struct vspm_drvdata *pdrv = priv->pdrv;
	struct device_node *np;

	long drv_ercd;
	int ercd;
	int i;

	DPRINT("called\n");

	/* enable clock */
	np = pdrv->tddmac_pdev->dev.of_node;
	pdrv->tddmac_clk = of_clk_get(np, 0);
	if (IS_ERR(pdrv->tddmac_clk)) {
		APRINT("failed to get 2DDMAC clock\n");
		ercd = -EFAULT;
		goto err_exit1;
	}

	ercd = clk_prepare_enable(pdrv->tddmac_clk);
	if (ercd < 0) {
		APRINT("failed to stating 2DDMAC clock\n");
		ercd = -EFAULT;
		goto err_exit2;
	}

	DPRINT("called 2\n");

	for(i=0; i<VSPM_IP_MAX; i++){
		if (pdrv->vsp_pdev[i]){
			np = pdrv->vsp_pdev[i]->dev.of_node;
			pdrv->vsp_clk[i] = of_clk_get(np, 0);
			if (IS_ERR(pdrv->vsp_clk[i])) {
				APRINT("failed to get 2DDMAC clock\n");
				ercd = -EFAULT;
				goto err_exit7;
			}
			ercd = clk_prepare_enable(pdrv->vsp_clk[i]);
			if (ercd < 0) {
				APRINT("failed to stating 2DDMAC clock\n");
				ercd = -EFAULT;
				clk_put(pdrv->vsp_clk[i]);
				pdrv->vsp_clk[i] = NULL;
				goto err_exit7;
			}
		}
	}

	DPRINT("called 3\n");

	drv_ercd = vspm_lib_driver_initialize(pdrv);
	if (drv_ercd != R_VSPM_OK) {
		APRINT("failed to vspm_lib_driver_initialize %d\n",
			(int)drv_ercd);
		ercd = -EFAULT;
		goto err_exit7;
	}

	/* Initialize the framework */
	fw_initialize();

	/* Register VSPM task to framework */
	ercd = fw_task_register(TASK_VSPM);
	if (ercd) {
		APRINT("failed to fw_task_register\n");
		ercd = -EFAULT;
		goto err_exit8;
	}

	/* create vspm thread */
	pdrv->task = kthread_run(vspm_thread, priv, THREADNAME);
	if (IS_ERR(pdrv->task)) {
		APRINT("failed to kthread_run\n");
		ercd = -EFAULT;
		goto err_exit9;
	}

	/* Send FUNC_TASK_INIT message */
	drv_ercd = fw_send_function(TASK_VSPM, FUNC_TASK_INIT, 0, NULL);
	if (drv_ercd != FW_OK) {
		APRINT("failed to fw_send_function(FUNC_TASK_INIT)\n");
		ercd = -EFAULT;
		goto err_exit10;
	}

	DPRINT("done\n");
	return 0;

err_exit10:
	/* Send FUNC_TASK_QUIT message */
	fw_send_function(TASK_VSPM, FUNC_TASK_QUIT, 0, NULL);
err_exit9:
	/* Unregister VSPM task */
	fw_task_unregister(TASK_VSPM);
err_exit8:
	vspm_lib_driver_quit();
err_exit7:
	for(i=0; i<VSPM_IP_MAX; i++){
		if (pdrv->vsp_clk[i]){
			clk_disable_unprepare(pdrv->vsp_clk[i]);
			clk_put(pdrv->vsp_clk[i]);
			pdrv->vsp_clk[i] = NULL;
		}
	}
	clk_disable_unprepare(pdrv->tddmac_clk);
err_exit2:
	clk_put(pdrv->tddmac_clk);
err_exit1:

	return ercd;
}

/*
 * vspm_quit - Exit the VSPM thread
 * @priv: VSPM driver private data
 *
 */
int vspm_quit(struct vspm_privdata *priv)
{
	struct vspm_drvdata *pdrv = priv->pdrv;

	long drv_ercd;
	int ercd, i;

	DPRINT("called\n");

	/* Send FUNC_TASK_QUIT message */
	drv_ercd = fw_send_function(TASK_VSPM, FUNC_TASK_QUIT, 0, NULL);
	if (drv_ercd != FW_OK) {
		APRINT("failed to fw_send_function(FUNC_TASK_QUIT)\n");
		ercd = -EFAULT;
		goto exit;
	}

	/* Unregister VSPM task */
	(void)fw_task_unregister(TASK_VSPM);

	drv_ercd = vspm_lib_driver_quit();
	if (drv_ercd != R_VSPM_OK) {
		APRINT("failed to vspm_lib_driver_quit %d\n", (int)drv_ercd);
		ercd = -EFAULT;
		goto exit;
	}

	/* disable clock */
	for(i=0; i<VSPM_IP_MAX; i++){
		if (pdrv->vsp_clk[i]){
			clk_disable_unprepare(pdrv->vsp_clk[i]);
			clk_put(pdrv->vsp_clk[i]);
			pdrv->vsp_clk[i] = NULL;
		}
	}
	clk_disable_unprepare(pdrv->tddmac_clk);
	clk_put(pdrv->tddmac_clk);

	DPRINT("done\n");
	return 0;

exit:
	return ercd;
}


/*
 * vspm_cancel - Cancel the VSPM thread
 * @priv: VSPM driver private data
 *
 */
int vspm_cancel(struct vspm_privdata *priv)
{
	long ercd;

	DPRINT("called\n");

	ercd = vspm_lib_forced_cancel((unsigned long)priv);
	if (ercd != R_VSPM_OK) {
		APRINT("failed to vspm_lib_forced_cancel %d\n", (int)ercd);
		return -EFAULT;
	}

	DPRINT("done\n");
	return 0;
}

